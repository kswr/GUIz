package com.company;

public class Freesia extends Flower{
    public Freesia(int amount){
        super("frezja", "purpurowy", amount);
    }
}
