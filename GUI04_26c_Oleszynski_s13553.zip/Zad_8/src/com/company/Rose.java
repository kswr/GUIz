package com.company;

public class Rose extends Flower{
    public Rose(int amount) {
        super("róża", "czerwony", amount);
    }
}
