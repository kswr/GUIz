package com.company;

public class Peony extends Flower{
    public Peony(int amount){
        super("piwonia", "czerwony", amount);
    }
}
